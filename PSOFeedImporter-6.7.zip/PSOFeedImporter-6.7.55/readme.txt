This is the Percussion Feed Importer

Install Content REST services version 6.7.

Install the PSO Toolkit 6.7

Install the PSO Feed Importer package.

Configure Package Visibility

Configure PSO Rest Service Authentication.

Edit AppServer/server/rx/deploy/rxapp.ear/rxapp.war/WEB-INF/config/user/spring/PSORestAPI-beans.xml

Change the server url and port to match your server configuration.  Specify the use rname and password that the
service will Authenticate into Rhythmyx with. 

